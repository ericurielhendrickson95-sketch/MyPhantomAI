# PhantomAI Enhanced Setup Guide ✨

Your PhantomAI has been upgraded with powerful new features:
- ✅ **No API key required** - Backend server handles authentication
- ✅ **Voice chatting** - Record voice messages and listen to responses
- ✅ **File embedding** - Upload documents, PDFs, images, and text files
- ✅ **Secure processing** - All data processed on your server

---

## Installation & Setup

### Step 1: Set Up Environment Variables

Create a `.env` file in the root directory (copy from `.env.example`):

```bash
cp .env.example .env
```

Edit `.env` and add your Anthropic API key:

```env
ANTHROPIC_API_KEY=sk-ant-your-actual-api-key-here
PORT=3001
NODE_ENV=development
```

Get your free API key: https://console.anthropic.com

### Step 2: Install Dependencies

```bash
npm install
```

### Step 3: Run in Development Mode

You have two options:

**Option A: Run frontend and backend separately** (easier for debugging)
```bash
# Terminal 1 - Frontend (Vite dev server on http://localhost:5173)
npm run dev

# Terminal 2 - Backend server (on http://localhost:3001)
npm run server
```

**Option B: Run both together**
```bash
npm run dev:full
```

### Step 4: Open in Browser

Go to: **http://localhost:5173**

That's it! No API key field in the UI - the server handles authentication. ✨

---

## New Features

### 🎙️ Voice Chatting

**Record a Voice Message:**
1. Click the **"🎙️ Record"** button
2. Speak your message (you'll see a waveform animation)
3. Click **"Stop"** when done
4. Click **"Send"** to submit

**Listen to AI Response:**
1. After the AI responds, click the **"🔊"** button
2. The AI's message will be read aloud using text-to-speech
3. Browser will use your system's text-to-speech engine

**Browser Compatibility:**
- ✅ Chrome, Edge, Safari (all modern versions)
- ✅ Firefox (Web Speech API support)
- ⚠️ Voice recording requires HTTPS or localhost

### 📎 File Embedding

**Attach a File:**
1. Click the **"📎 File"** button
2. Select a file from your computer
3. You'll see a preview showing the filename and size
4. Type your question about the file
5. Click **"Send"**

**Supported File Types:**
- 📄 **Text**: `.txt`, `.md` (plain text files)
- 📊 **PDF**: Full document extraction
- 🖼️ **Images**: `.jpg`, `.png`, `.gif`, `.webp`
- 📋 **JSON**: Structured data files
- 📚 **Size Limit**: Up to 50MB per file

**How It Works:**
- File content is automatically extracted and attached to your message
- The AI can analyze, summarize, or answer questions about the file
- For PDFs, the first 10,000 characters are used to avoid token limits
- For images, the system notes the image is present (visual analysis available with vision APIs)

**Example Scenarios:**
- "📎 Attach a PDF contract → Ask 'What are the key terms?'"
- "📎 Attach an image → Ask 'What's in this screenshot?'"
- "📎 Attach a log file → Ask 'Are there any errors?'"

### 🧠 Voice + Files Combined

You can use voice and files together:

1. Click **"🎙️ Record"** to record a question
2. Click **"📎 File"** to attach a document
3. Click **"Send"** to submit both together

---

## Deployment

### Production Build

```bash
npm run build
```

This creates an optimized `dist/` folder.

### Run Production Server

```bash
NODE_ENV=production npm run start
```

The server will:
- Serve the compiled frontend from `/dist`
- Listen on port 3001 (or your `PORT` env var)
- Handle all API requests securely

### Docker Deployment (Optional)

Create a `Dockerfile`:

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY . .
RUN npm run build
EXPOSE 3001
CMD ["npm", "start"]
```

Build and run:
```bash
docker build -t phantomai .
docker run -p 3001:3001 -e ANTHROPIC_API_KEY=sk-ant-... phantomai
```

---

## Configuration

### Backend API Endpoints

All endpoints are handled by the Express backend:

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/chat` | POST | Send message with optional file |
| `/api/health` | GET | Check server status |
| `/` | GET | Serve frontend (index.html) |

### Environment Variables

```env
ANTHROPIC_API_KEY    # Your Anthropic API key (required)
PORT                 # Server port (default: 3001)
NODE_ENV            # development or production
```

### File Upload Limits

In `server.js`, you can adjust:

```javascript
limits: { fileSize: 50 * 1024 * 1024 }  // Change 50 to desired MB
```

### Model Selection

Change the model in `server.js`:

```javascript
model: 'claude-opus-4-1'  // Change to another model
```

Available models:
- `claude-opus-4-1` (most capable)
- `claude-sonnet-4-20250514` (balanced)
- `claude-haiku-3-5` (fastest, cheapest)

---

## Troubleshooting

### "Server connection failed"
- ✅ Make sure backend is running: `npm run server`
- ✅ Check that the server is on port 3001
- ✅ Verify CORS is enabled (it should be)

### "Microphone access denied"
- ✅ Check browser microphone permissions
- ✅ Ensure you're using HTTPS or localhost
- ✅ Firefox/Chrome require explicit permission

### "API key is invalid"
- ✅ Get a fresh key from https://console.anthropic.com
- ✅ Make sure it starts with `sk-ant-`
- ✅ Check it's correctly set in `.env` file
- ✅ Restart the server after changing `.env`

### "File type not supported"
- ✅ Check file extension and MIME type
- ✅ Supported: `.txt`, `.md`, `.pdf`, `.jpg`, `.png`, `.gif`, `.webp`, `.json`
- ✅ File must be under 50MB

### "No memories appearing"
- ✅ Have conversations about your preferences
- ✅ AI learns from context, not every message
- ✅ Memories appear in the sidebar after learning

### Voice feature not working
- ✅ Check browser supports Web Speech API
- ✅ Ensure you granted microphone permission
- ✅ Try Chrome/Edge for best compatibility

---

## Security Notes

### API Key Security
- ✅ API key is stored **server-side only** (.env file)
- ✅ Not exposed to the browser
- ✅ Requests go through your server, not directly to Anthropic
- ✅ Never commit `.env` to version control

### File Uploads
- ✅ Files are processed in memory, not stored
- ✅ 50MB size limit prevents abuse
- ✅ Only specified MIME types accepted
- ✅ File content extracted and used only for the current request

### Data Privacy
- ✅ Conversation history stored locally in browser
- ✅ Files not stored on server after processing
- ✅ Only communication: your message → API → response
- ✅ No data collected or logged (except console)

---

## Advanced Features

### Custom System Prompt

Edit the `buildSystemPrompt()` function in `index.html` to customize AI behavior:

```javascript
function buildSystemPrompt() {
  return `You are PhantomAI, a custom AI assistant...`
}
```

### Add More Memory Tags

Modify the learning system to recognize additional concepts:

```javascript
// In parseAndLearn() function
const validTags = ['preference', 'interest', 'goal', 'skill', 'YOUR_TAG'];
```

### Integrate External APIs

Extend the backend to call other services:

```javascript
// In server.js
app.post('/api/custom', async (req, res) => {
  // Your custom logic here
});
```

---

## Development Workflow

### Frontend Only (No Backend)
```bash
npm run dev
```
(Won't work without backend running - just for UI development)

### Full Stack Development
```bash
npm run dev:full
```

### Production Build
```bash
npm run build
NODE_ENV=production npm run start
```

---

## File Structure

```
MyPhantomAI/
├── server.js              ← Express backend (NEW)
├── .env                   ← Environment variables (NEW)
├── .env.example          ← Example env file (NEW)
├── package.json          ← Updated with new scripts
├── index.html            ← Updated with voice/file UI
├── vite.config.js
├── public/
│   └── assets/
│       └── phantom-logo.png
├── src/                  ← Frontend source (if using React)
└── dist/                 ← Built frontend (generated)
```

---

## Performance Tips

1. **Use lighter models** for faster responses:
   ```javascript
   model: 'claude-haiku-3-5'  // Fastest
   ```

2. **Reduce context window** for cheaper API calls:
   ```javascript
   messages: conversationHistory.slice(-10)  // Last 10 messages only
   ```

3. **Cache frequently asked questions** in memory

4. **Compress files** before uploading (especially PDFs)

---

## Next Steps

1. ✅ Copy `.env.example` to `.env`
2. ✅ Add your API key to `.env`
3. ✅ Run `npm install`
4. ✅ Start backend: `npm run server`
5. ✅ Start frontend: `npm run dev`
6. ✅ Open http://localhost:5173
7. ✅ Try voice recording! 🎙️
8. ✅ Upload a file and ask questions! 📎

---

## Support & Resources

- **Anthropic Docs**: https://docs.anthropic.com
- **API Reference**: https://docs.anthropic.com/en/api/messages
- **Console**: https://console.anthropic.com
- **Pricing**: https://www.anthropic.com/pricing
- **Web Speech API**: https://developer.mozilla.org/en-US/docs/Web/API/Web_Speech_API

---

**PhantomAI is now fully enhanced!** 🖤✨

Questions? Check the main README or open an issue on GitHub.
