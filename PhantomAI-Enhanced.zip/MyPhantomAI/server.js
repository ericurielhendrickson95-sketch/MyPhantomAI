import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import Anthropic from '@anthropic-ai/sdk';
import pdfParse from 'pdf-parse';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'dist')));

// File upload configuration
const storage = multer.memoryStorage();
const upload = multer({ 
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB limit
  fileFilter: (req, file, cb) => {
    const allowedMimes = [
      'text/plain',
      'text/markdown',
      'application/pdf',
      'image/jpeg',
      'image/png',
      'image/gif',
      'image/webp',
      'application/json'
    ];
    
    if (allowedMimes.includes(file.mimetype) || file.originalname.endsWith('.txt') || file.originalname.endsWith('.md')) {
      cb(null, true);
    } else {
      cb(new Error('File type not supported'), false);
    }
  }
});

// Initialize Anthropic client
const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY
});

// Helper function to extract text from files
async function extractFileContent(file) {
  try {
    if (file.mimetype === 'application/pdf') {
      const data = await pdfParse(file.buffer);
      return {
        name: file.originalname,
        type: 'pdf',
        content: data.text.substring(0, 10000), // Limit to 10k chars
        size: file.size
      };
    } else if (file.mimetype === 'text/plain' || file.mimetype === 'text/markdown' || 
               file.originalname.endsWith('.txt') || file.originalname.endsWith('.md')) {
      return {
        name: file.originalname,
        type: 'text',
        content: file.buffer.toString('utf8').substring(0, 10000),
        size: file.size
      };
    } else if (file.mimetype.startsWith('image/')) {
      return {
        name: file.originalname,
        type: 'image',
        content: `[Image: ${file.originalname}]`,
        base64: file.buffer.toString('base64'),
        mimeType: file.mimetype,
        size: file.size
      };
    } else if (file.mimetype === 'application/json') {
      const content = JSON.parse(file.buffer.toString('utf8'));
      return {
        name: file.originalname,
        type: 'json',
        content: JSON.stringify(content, null, 2).substring(0, 10000),
        size: file.size
      };
    }
  } catch (error) {
    console.error('Error extracting file content:', error);
    return {
      name: file.originalname,
      type: 'unknown',
      content: `[File: ${file.originalname} - could not be parsed]`,
      error: error.message,
      size: file.size
    };
  }
}

// Chat endpoint with optional file upload
app.post('/api/chat', upload.single('file'), async (req, res) => {
  try {
    const { messages, systemPrompt } = req.body;

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Messages must be an array' });
    }

    // Process uploaded file if present
    let fileContext = '';
    if (req.file) {
      const fileData = await extractFileContent(req.file);
      fileContext = `\n\n[Attached File: ${fileData.name}]\n${fileData.content}`;
      
      // Append file context to the last user message
      if (messages.length > 0 && messages[messages.length - 1].role === 'user') {
        messages[messages.length - 1].content += fileContext;
      }
    }

    // Call Anthropic API
    const response = await client.messages.create({
      model: 'claude-opus-4-1',
      max_tokens: 2048,
      system: systemPrompt || 'You are a helpful AI assistant.',
      messages: messages.map(msg => ({
        role: msg.role,
        content: msg.content
      }))
    });

    const assistantMessage = response.content[0].type === 'text' ? response.content[0].text : '';

    res.json({
      success: true,
      message: assistantMessage,
      usage: {
        inputTokens: response.usage.input_tokens,
        outputTokens: response.usage.output_tokens
      }
    });

  } catch (error) {
    console.error('Chat error:', error);
    res.status(500).json({ 
      error: error.message || 'Failed to process chat request'
    });
  }
});

// Transcription endpoint (speech-to-text)
app.post('/api/transcribe', upload.single('audio'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No audio file provided' });
    }

    // For now, we'll use the Web Speech API on the client side
    // This is a placeholder for server-side transcription if needed
    res.json({ 
      success: true,
      message: 'Use Web Speech API on client side for transcription'
    });

  } catch (error) {
    console.error('Transcription error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Text-to-speech endpoint
app.post('/api/speak', async (req, res) => {
  try {
    const { text } = req.body;

    if (!text) {
      return res.status(400).json({ error: 'No text provided' });
    }

    // For now, we'll use the Web Speech API on the client side
    // This is a placeholder for server-side TTS if needed
    res.json({
      success: true,
      message: 'Use Web Speech API on client side for text-to-speech'
    });

  } catch (error) {
    console.error('TTS error:', error);
    res.status(500).json({ error: error.message });
  }
});

// File validation endpoint
app.post('/api/validate-file', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file provided' });
    }

    const fileData = await extractFileContent(req.file);
    res.json({
      success: true,
      file: {
        name: fileData.name,
        type: fileData.type,
        size: fileData.size,
        preview: fileData.content.substring(0, 200) + (fileData.content.length > 200 ? '...' : '')
      }
    });

  } catch (error) {
    console.error('File validation error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', apiConfigured: !!process.env.ANTHROPIC_API_KEY });
});

// Serve the index.html for all other routes (SPA)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'), (err) => {
    if (err) {
      res.sendFile(path.join(__dirname, 'index.html'));
    }
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, () => {
  console.log(`🖤 PhantomAI Server running on http://localhost:${PORT}`);
  console.log(`API Key configured: ${!!process.env.ANTHROPIC_API_KEY}`);
});
