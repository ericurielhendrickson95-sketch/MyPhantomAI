# PhantomAI Enhanced - Quick Start ⚡✨

## 3 Steps to Get Running (With Voice & Files!)

### Step 1: Environment Setup
```bash
cp .env.example .env
# Edit .env and add your API key from https://console.anthropic.com
```

### Step 2: Install & Start
```bash
npm install
npm run dev:full
```

### Step 3: Open & Chat
- Go to: **http://localhost:5173**
- No API key field in UI! ✨
- Try **🎙️ Record** to speak
- Try **📎 File** to upload documents

---

## What's New

### 🎙️ Voice Chat
Record messages instead of typing. Click "Record", speak, click "Send"!
Listen to AI responses with the 🔊 button.

### 📎 File Embedding  
Upload PDFs, images, text files. Ask questions about them!
Supported: `.txt`, `.md`, `.pdf`, `.jpg`, `.png`, `.gif`, `.json` (max 50MB)

### 🔒 No API Key Needed
API key stored securely on the server, not exposed in browser!

---

## Commands

| Command | What it does |
|---------|------------|
| `npm run dev:full` | Run frontend + backend together |
| `npm run dev` | Frontend only (on port 5173) |
| `npm run server` | Backend only (on port 3001) |
| `npm run build` | Production build |
| `npm start` | Run production server |

---

## Features

✅ **Backend Server** - Express.js for secure API handling
✅ **Voice Recording** - Use Web Speech API for voice input
✅ **Text-to-Speech** - Listen to AI responses
✅ **File Upload** - Support for PDFs, images, text, JSON
✅ **No API Key in UI** - Secure server-side authentication
✅ **Memory System** - Learns your preferences
✅ **Beautiful UI** - Dark theme with ghost logo

---

## Environment Setup

Create `.env` file with:
```env
ANTHROPIC_API_KEY=sk-ant-your-key-here
PORT=3001
NODE_ENV=development
```

Get your free API key at: https://console.anthropic.com

---

## Troubleshooting

**"Server connection failed"**
- Run `npm run server` in a separate terminal
- Check port 3001 is not in use

**"Microphone not working"**
- Check browser permissions
- Use Chrome/Edge for best support
- Must be HTTPS or localhost

**"Invalid API key"**
- Get a fresh key from console.anthropic.com
- Restart server after updating .env
- Key should start with `sk-ant-`

**"File type not supported"**
- Only `.txt`, `.md`, `.pdf`, `.jpg`, `.png`, `.gif`, `.webp`, `.json`
- Max file size: 50MB

---

## Full Guide

See `ENHANCED_SETUP.md` for comprehensive documentation including:
- Detailed feature explanations
- Deployment instructions
- Security considerations
- API endpoint reference
- Performance optimization tips

---

## Architecture

```
Frontend (Vite)      Backend (Express)      Anthropic API
   ↓                        ↓                     ↓
Voice/File Input → /api/chat → Process & Auth → Claude
   ↓                        ↓                     ↓
Chat Display    ← Response ← Response         Response
```

---

**Ready to go!** Run `npm run dev:full` and start chatting with voice! 🎙️✨
