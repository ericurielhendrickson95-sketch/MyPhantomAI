import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import Chat from './pages/Chat';
import Memories from './pages/Memories';
import Settings from './pages/Settings';
import PaywallGate from './components/PaywallGate';
import PrivacyPolicy from './pages/PrivacyPolicy';
import Tasks from './pages/Tasks';
// Add page imports here

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();
  const location = useLocation();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  const path = location.pathname;
  const isChatTab = path === '/' || path.startsWith('/chat');
  const isMemoriesTab = path === '/memories';
  const isSettingsTab = path === '/settings';
  const isPrivacyTab = path === '/privacy';
  const isTasksTab = path === '/tasks';

  // Use Routes to enable useParams in Chat, but keep all tabs mounted for state preservation
  return (
    <PaywallGate>
      <div style={{ position: 'absolute', inset: 0 }}>
        {/* Chat tab: always mounted, shown/hidden. Routes provides :id param context. */}
        <div style={{ display: isChatTab ? 'flex' : 'none', flexDirection: 'column', height: '100%' }}>
          <Routes>
            <Route path="/" element={<Chat />} />
            <Route path="/chat/:id" element={<Chat />} />
          </Routes>
        </div>
        <div style={{ display: isMemoriesTab ? 'flex' : 'none', flexDirection: 'column', height: '100%' }}>
          <Memories />
        </div>
        <div style={{ display: isSettingsTab ? 'flex' : 'none', flexDirection: 'column', height: '100%' }}>
          <Settings />
        </div>
        <div style={{ display: isPrivacyTab ? 'flex' : 'none', flexDirection: 'column', height: '100%' }}>
          <PrivacyPolicy />
        </div>
        <div style={{ display: isTasksTab ? 'flex' : 'none', flexDirection: 'column', height: '100%' }}>
          <Tasks />
        </div>
        {!isChatTab && !isMemoriesTab && !isSettingsTab && !isPrivacyTab && !isTasksTab && <PageNotFound />}
      </div>
    </PaywallGate>
  );
};


function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <div style={{ position: 'relative', height: '100dvh', overflow: 'hidden' }}>
            <AuthenticatedApp />
          </div>
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  );
}

export default App