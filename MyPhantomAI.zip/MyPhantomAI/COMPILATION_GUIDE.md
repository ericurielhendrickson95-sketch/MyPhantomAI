# MyPhantom AI - Build & Compilation Guide

## ✅ Build Setup Complete

Your MyPhantom AI is now configured to compile into applications for all platforms.

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
npm install -g electron-builder
```

### 2. Build for Your Platform

**Windows (.exe installer)**
```bash
npm run build:desktop:win
# Output: dist/MyPhantom AI Setup x.x.x.exe
```

**macOS (.dmg)**
```bash
npm run build:desktop:mac
# Output: dist/MyPhantom AI x.x.x.dmg
```

**Linux (.AppImage)**
```bash
npm run build:desktop:linux
# Output: dist/MyPhantom AI x.x.x.AppImage
```

**All Platforms (Windows + macOS + Linux)**
```bash
npm run build:desktop:all
```

**Web (static files)**
```bash
npm run build
# Output: dist/ (ready to deploy)
```

**Android (if available)**
```bash
npm run build:mobile
```

## 📦 Build Outputs

| Platform | Command | Output File | Size |
|----------|---------|------------|------|
| **Windows** | `npm run build:desktop:win` | MyPhantom AI Setup x.x.x.exe | ~150-200MB |
| **macOS** | `npm run build:desktop:mac` | MyPhantom AI x.x.x.dmg | ~200-250MB |
| **Linux** | `npm run build:desktop:linux` | MyPhantom AI x.x.x.AppImage | ~150-180MB |
| **Web** | `npm run build` | dist/ folder | ~2-5MB |
| **Android** | `npm run build:mobile` | .aab/.apk | ~40-100MB |

## 🔄 Automated Builds (GitHub Actions)

Push a tag to automatically build for all platforms:

```bash
git tag v1.0.0
git push origin v1.0.0
```

This triggers the workflow in `.github/workflows/build.yml` which:
- ✅ Builds Windows, macOS, Linux executables
- ✅ Compiles web bundle
- ✅ Packages Android app
- ✅ Creates GitHub Release with all artifacts

## 🌐 Deploy Web Version

```bash
# Vercel
npm install -g vercel
vercel deploy dist --prod

# Netlify
npm install -g netlify-cli
netlify deploy --prod --dir dist

# GitHub Pages
npm run build
git add dist
git commit -m "Deploy"
git push
```

## 📱 Desktop App Distribution

**Windows:**
1. Build: `npm run build:desktop:win`
2. Upload to: GitHub Releases, or website
3. Users download: `MyPhantom AI Setup x.x.x.exe`

**macOS:**
1. Build: `npm run build:desktop:mac`
2. Optional: Code sign with Apple certificate
3. Upload to: GitHub Releases, or website
4. Users download: `MyPhantom AI x.x.x.dmg`

**Linux:**
1. Build: `npm run build:desktop:linux`
2. Upload to: GitHub Releases, or AppImage repository
3. Users run: `chmod +x MyPhantom\ AI-x.x.x.AppImage && ./MyPhantom\ AI-x.x.x.AppImage`

## 🔐 Code Signing (Optional)

### Windows Code Signing
```bash
# Using self-signed cert (for testing)
npm run build:desktop:win
```

### macOS Code Signing
Requires Apple Developer account:
```bash
export CSC_IDENTITY_AUTO_DISCOVERY=false
export CSC_KEY_PASSWORD=your_password
npm run build:desktop:mac
```

## 🐛 Troubleshooting

### Build fails on Windows
```bash
# Install build tools
npm install -g windows-build-tools

# Clear cache
npm cache clean --force
rm -r dist node_modules
npm install
```

### macOS build issues
```bash
# Update Xcode command line tools
xcode-select --install

# Clear Xcode cache
rm -rf ~/Library/Developer/Xcode/DerivedData/*
```

### Linux build issues
```bash
# Install required dependencies
sudo apt-get install libgconf-2-4 libappindicator1 libindicator7

# Or use Docker
docker run -it node:18 bash
npm install
npm run build:desktop:linux
```

## 📋 Release Checklist

- [ ] Update version in `package.json`
- [ ] Test on target platform
- [ ] Run `npm run build:desktop:*`
- [ ] Create git tag: `git tag v1.0.0`
- [ ] Push tag: `git push origin v1.0.0`
- [ ] GitHub Actions builds automatically
- [ ] Download artifacts from GitHub Release
- [ ] Create announcement

## 📊 Build Configuration Files

- `package.json` - Build scripts and Electron config
- `electron/main.js` - Electron main process
- `electron/preload.js` - Electron security context
- `vite.config.js` - Vite build configuration
- `.github/workflows/build.yml` - Automated builds

## 🎯 Next Steps

1. **Test locally**: `npm run dev` then `npm run build:desktop:win`
2. **Create release**: Tag and push to GitHub
3. **Distribute**: Share generated .exe/.dmg/.AppImage files
4. **Monitor**: Track downloads and user feedback

---

**Your app is ready for compilation and distribution! 🎉**
