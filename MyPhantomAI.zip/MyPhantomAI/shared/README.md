# Shared Library

Cross-platform utilities and hooks for MyPhantom AI web and mobile apps.

## Structure

```
shared/
├── lib/
│   ├── context/       # React context providers
│   ├── hooks/         # Custom React hooks
│   ├── types/         # TypeScript types and interfaces
│   └── utils/         # Utility functions
└── package.json       # Shared library dependencies
```

## Exports

### Hooks
- `useAuth()` - Authentication hook with login/logout
- `useMobile()` - Detect if running on mobile

### Utils
- `apiCall<T>()` - Fetch wrapper with error handling
- `getItem()`, `setItem()`, `removeItem()` - Platform-specific storage

### Types
- `User` - User profile type
- `Message` - Chat message type
- `Conversation` - Conversation type

### Context
- `AuthProvider` - Authentication context provider
- `useAuthContext()` - Hook to access auth context

## Usage

### Web App
```typescript
import { useAuth } from '@myphantom/shared/hooks';
import { apiCall } from '@myphantom/shared/utils';
```

### Mobile App
```typescript
import { useAuth } from '@myphantom/shared/hooks';
import { apiCall } from '@myphantom/shared/utils';
```

## Development

Add new shared utilities here to keep code DRY across platforms.

## Notes

- Platform-specific implementations should remain in respective app folders
- Keep business logic in this shared library
- Use TypeScript for type safety
