// Hook to detect if running on mobile platform
export function useMobile(): boolean {
  try {
    // This will be overridden by platform-specific implementations
    if (typeof window !== 'undefined') {
      return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
        navigator.userAgent
      );
    }
    return false;
  } catch {
    return false;
  }
}
