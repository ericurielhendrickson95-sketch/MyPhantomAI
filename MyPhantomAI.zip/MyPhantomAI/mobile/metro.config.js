/**
 * metro.config.js
 * Expo Metro configuration to properly resolve monorepo packages
 */

const { getDefaultConfig } = require('expo/metro-config');
const { withNativeWind } = require('nativewind/metro');

const config = getDefaultConfig(__dirname);

// Add support for monorepo path resolution
config.projectRoot = __dirname;
config.watchFolders = [
  __dirname,
  require('path').resolve(__dirname, '../shared'),
];

module.exports = withNativeWind(config, { input: './global.css' });
