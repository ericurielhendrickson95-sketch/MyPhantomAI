# Monorepo Setup Guide

## Project Structure

```
MyPhantomAI/
├── web/                 # Existing Vite + React web app
├── mobile/              # New Expo React Native app
├── shared/              # Shared utilities, hooks, types
└── root-package.json    # Monorepo workspace config
```

## Key Features

- **Shared Code**: Common utilities, types, and hooks in `shared/`
- **Independent Apps**: Web and mobile apps can be developed and deployed separately
- **Monorepo Scripts**: Run commands across both apps from root

## Getting Started

### 1. Install Dependencies

```bash
# Install all monorepo dependencies
npm install

# Or install for specific workspace
npm install -w mobile
npm install -w web
```

### 2. Run Web App

```bash
npm run dev:web
# Runs on http://localhost:5173
```

### 3. Run Mobile App

```bash
npm run dev:mobile
# Starts Expo development server

# iOS
npm run dev:ios

# Android
npm run dev:android
```

## Migration Strategy

### Phase 1: Shared Code (Current)
- ✅ Extract authentication logic
- ✅ Create shared types
- ✅ Set up API utilities
- ✅ Create shared hooks

### Phase 2: Mobile Components
- [ ] Create mobile-specific chat interface
- [ ] Implement native navigation
- [ ] Add platform-specific features (camera, voice)
- [ ] Set up secure storage

### Phase 3: Feature Parity
- [ ] Migrate core features to mobile
- [ ] Test across both platforms
- [ ] Optimize performance

### Phase 4: Deployment
- [ ] Configure app signing
- [ ] Set up CI/CD pipeline
- [ ] Deploy to App Store and Play Store

## Development Tips

- Use `@myphantom/shared` imports for shared code
- Platform-specific code goes in respective app folders
- Keep business logic in `shared/lib/`
- Use TypeScript for better type safety

## Next Steps

1. Move existing web app to `web/` folder
2. Configure Firebase/Backend for mobile
3. Add push notifications support
4. Implement in-app updates with EAS

## Resources

- [Expo Documentation](https://docs.expo.dev/)
- [React Native Best Practices](https://reactnative.dev/)
- [Monorepo Structure Guide](https://pnpm.io/workspaces)
