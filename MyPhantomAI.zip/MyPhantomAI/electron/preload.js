const { contextBridge, ipcMain } = require('electron');

// Expose limited API to renderer process
contextBridge.exposeInMainWorld('api', {
  send: (channel, data) => {
    ipcMain.send(channel, data);
  },
  receive: (channel, func) => {
    ipcMain.on(channel, (event, ...args) => func(...args));
  },
});
