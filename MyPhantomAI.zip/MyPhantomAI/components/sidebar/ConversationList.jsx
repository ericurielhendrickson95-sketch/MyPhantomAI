import React from 'react';
import { Plus, MessageSquare, Trash2, Brain, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';

export default function ConversationList({
  conversations,
  activeId,
  onSelect,
  onCreate,
  onDelete,
  onClose,
  memoryCount,
  onViewMemories,
}) {
  return (
    <div className="h-full flex flex-col bg-sidebar border-r border-sidebar-border">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-4 border-b border-sidebar-border">
        <h2 className="font-heading text-sm font-bold tracking-[0.1em] text-primary">THREADS</h2>
        <div className="flex gap-2">
          <button
            onClick={onCreate}
            className="p-2 rounded-lg bg-primary/10 border border-primary/25 text-primary hover:bg-primary/20 transition-colors"
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            onClick={onClose}
            className="md:hidden p-2 rounded-lg hover:bg-secondary transition-colors text-muted-foreground"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Conversations */}
      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        <AnimatePresence>
          {conversations.map((conv) => (
            <motion.div
              key={conv.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              className={`group flex items-center gap-3 px-3 py-3 rounded-lg cursor-pointer transition-all ${
                activeId === conv.id
                  ? 'bg-primary/10 border border-primary/20'
                  : 'hover:bg-secondary/50 border border-transparent'
              }`}
              onClick={() => onSelect(conv.id)}
            >
              <MessageSquare className="w-4 h-4 text-primary/50 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs text-foreground truncate">{conv.title || 'New Thread'}</p>
                <p className="text-[10px] text-muted-foreground truncate mt-0.5">
                  {conv.last_message_preview || 'No messages yet'}
                </p>
              </div>
              <button
                onClick={(e) => { e.stopPropagation(); onDelete(conv.id); }}
                className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-destructive/20 transition-all"
              >
                <Trash2 className="w-3 h-3 text-destructive/60" />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>

        {conversations.length === 0 && (
          <div className="text-center text-muted-foreground text-xs py-12">
            No threads yet. Start a new one.
          </div>
        )}
      </div>

      {/* Memory panel */}
      <div className="border-t border-sidebar-border p-3">
        <button
          onClick={onViewMemories}
          className="w-full flex items-center gap-2 px-3 py-2.5 rounded-lg bg-accent/5 border border-accent/15 text-accent/80 hover:bg-accent/10 transition-colors text-[11px] tracking-wide"
        >
          <Brain className="w-3.5 h-3.5" />
          <span>Memories</span>
          {memoryCount > 0 && (
            <span className="ml-auto bg-accent/20 px-1.5 py-0.5 rounded text-[10px]">{memoryCount}</span>
          )}
        </button>
      </div>
    </div>
  );
}