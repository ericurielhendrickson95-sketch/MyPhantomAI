import React, { useState } from 'react';
import { Brain, X, Trash2, Tag, Search, Pencil, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const categoryColors = {
  preference: 'text-primary border-primary/20 bg-primary/5',
  personal: 'text-accent border-accent/20 bg-accent/5',
  work: 'text-emerald-400 border-emerald-400/20 bg-emerald-400/5',
  interest: 'text-amber-400 border-amber-400/20 bg-amber-400/5',
  habit: 'text-rose-400 border-rose-400/20 bg-rose-400/5',
  goal: 'text-cyan-400 border-cyan-400/20 bg-cyan-400/5',
};

const CATEGORIES = ['preference', 'personal', 'work', 'interest', 'habit', 'goal'];

function MemoryItem({ memory, onDelete, onEdit }) {
  const [editing, setEditing] = useState(false);
  const [editFact, setEditFact] = useState(memory.fact);
  const [editCategory, setEditCategory] = useState(memory.category);

  const handleSave = () => {
    onEdit(memory.id, { fact: editFact, category: editCategory });
    setEditing(false);
  };

  return (
    <motion.div
      key={memory.id}
      initial={{ opacity: 0, y: 5 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="group p-3 rounded-lg bg-secondary/30 border border-border hover:border-accent/20 transition-all"
    >
      {editing ? (
        <div className="space-y-2">
          <textarea
            value={editFact}
            onChange={(e) => setEditFact(e.target.value)}
            className="w-full bg-background border border-border rounded-md px-2 py-1.5 text-xs text-foreground resize-none outline-none focus:border-accent/50 leading-relaxed"
            rows={3}
            autoFocus
          />
          <div className="flex items-center gap-2">
            <select
              value={editCategory}
              onChange={(e) => setEditCategory(e.target.value)}
              className="flex-1 bg-background border border-border rounded-md px-2 py-1 text-[10px] text-foreground outline-none focus:border-accent/50"
            >
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
            <button
              onClick={handleSave}
              className="p-1.5 rounded-md bg-accent/20 hover:bg-accent/30 transition-colors"
            >
              <Check className="w-3 h-3 text-accent" />
            </button>
            <button
              onClick={() => { setEditing(false); setEditFact(memory.fact); setEditCategory(memory.category); }}
              className="p-1.5 rounded-md hover:bg-secondary transition-colors"
            >
              <X className="w-3 h-3 text-muted-foreground" />
            </button>
          </div>
        </div>
      ) : (
        <>
          <p className="text-xs text-foreground leading-relaxed">{memory.fact}</p>
          <div className="flex items-center justify-between mt-2">
            <span className={`inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full border ${categoryColors[memory.category] || categoryColors.personal}`}>
              <Tag className="w-2.5 h-2.5" />
              {memory.category}
            </span>
            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all">
              <button
                onClick={() => setEditing(true)}
                className="p-1 rounded hover:bg-accent/20 transition-colors"
              >
                <Pencil className="w-3 h-3 text-accent/60" />
              </button>
              <button
                onClick={() => onDelete(memory.id)}
                className="p-1 rounded hover:bg-destructive/20 transition-colors"
              >
                <Trash2 className="w-3 h-3 text-destructive/60" />
              </button>
            </div>
          </div>
        </>
      )}
    </motion.div>
  );
}

export default function MemoryPanel({ memories, onClose, onDelete, onEdit }) {
  const [search, setSearch] = useState('');

  const filtered = memories.filter((m) =>
    m.fact.toLowerCase().includes(search.toLowerCase()) ||
    m.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <motion.div
      initial={{ x: -280 }}
      animate={{ x: 0 }}
      exit={{ x: -280 }}
      transition={{ type: 'spring', damping: 25 }}
      className="absolute inset-0 z-30 bg-sidebar flex flex-col"
    >
      <div className="flex items-center justify-between px-4 py-4 border-b border-sidebar-border">
        <div className="flex items-center gap-2">
          <Brain className="w-4 h-4 text-accent" />
          <h2 className="font-heading text-sm font-bold tracking-[0.1em] text-accent">MEMORIES</h2>
        </div>
        <button onClick={onClose} className="p-2 rounded-lg hover:bg-secondary transition-colors">
          <X className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>

      {/* Search bar */}
      <div className="px-3 py-2 border-b border-sidebar-border">
        <div className="flex items-center gap-2 bg-secondary/40 border border-border rounded-lg px-3 py-2">
          <Search className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search memories..."
            className="flex-1 bg-transparent text-xs text-foreground placeholder:text-muted-foreground/50 outline-none"
          />
          {search && (
            <button onClick={() => setSearch('')}>
              <X className="w-3 h-3 text-muted-foreground hover:text-foreground transition-colors" />
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        <AnimatePresence>
          {filtered.map((memory) => (
            <MemoryItem
              key={memory.id}
              memory={memory}
              onDelete={onDelete}
              onEdit={onEdit}
            />
          ))}
        </AnimatePresence>

        {filtered.length === 0 && (
          <div className="text-center text-muted-foreground text-xs py-16 space-y-2">
            <Brain className="w-8 h-8 mx-auto text-accent/30" />
            {search ? (
              <p>No memories match "{search}"</p>
            ) : (
              <>
                <p>No memories yet.</p>
                <p className="text-[10px]">PhantomAI will learn about you as you chat.</p>
              </>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
}