import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Mic, MicOff, X, Volume2 } from 'lucide-react';

const NEW_LOGO = 'https://media..com/images/public/69fa9e4b7a5f8d62d51732e5/3a0e11972_NewProject.png';
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const WAKE_WORDS = ['hey phantom', 'hey, phantom'];

export default function VoiceMode({ onTranscript, isSpeaking, onClose, disabled }) {
  const [phase, setPhase] = useState('idle'); // idle | listening | processing
  const recognitionRef = useRef(null);
  const isListeningRef = useRef(false);
  const wakeListenerRef = useRef(null);

  // When AI finishes speaking or typing, go back to idle and restart wake word listener
  useEffect(() => {
    if (!isSpeaking && !disabled && phase === 'processing') {
      setPhase('idle');
    }
  }, [isSpeaking, disabled, phase]);

  // Start continuous wake word listener
  const startWakeWordListener = useCallback(() => {
    if (!SpeechRecognition || wakeListenerRef.current) return;

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = (e) => {
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const transcript = e.results[i][0].transcript.toLowerCase().trim();
        if (WAKE_WORDS.some((w) => transcript.includes(w))) {
          recognition.stop();
          wakeListenerRef.current = null;
          startListening();
          return;
        }
      }
    };

    recognition.onend = () => {
      // Restart if we're still in idle (not actively listening)
      if (wakeListenerRef.current) {
        wakeListenerRef.current = null;
        setTimeout(startWakeWordListener, 300);
      }
    };

    recognition.onerror = () => {
      wakeListenerRef.current = null;
    };

    wakeListenerRef.current = recognition;
    recognition.start();
  }, []); // eslint-disable-line

  // Start/stop wake word listener based on phase
  useEffect(() => {
    if (phase === 'idle' && !isSpeaking && !disabled) {
      startWakeWordListener();
    } else {
      if (wakeListenerRef.current) {
        wakeListenerRef.current.stop();
        wakeListenerRef.current = null;
      }
    }
    return () => {
      if (wakeListenerRef.current) {
        wakeListenerRef.current.stop();
        wakeListenerRef.current = null;
      }
    };
  }, [phase, isSpeaking, disabled, startWakeWordListener]);

  const startListening = useCallback(() => {
    if (!SpeechRecognition || isListeningRef.current) return;

    // Stop wake word listener first
    if (wakeListenerRef.current) {
      wakeListenerRef.current.stop();
      wakeListenerRef.current = null;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onresult = (e) => {
      const transcript = e.results[0][0].transcript.trim();
      isListeningRef.current = false;
      if (transcript) {
        setPhase('processing');
        onTranscript(transcript);
      } else {
        setPhase('idle');
      }
    };

    recognition.onerror = () => {
      isListeningRef.current = false;
      setPhase('idle');
    };

    recognition.onend = () => {
      isListeningRef.current = false;
      setPhase((prev) => (prev === 'listening' ? 'idle' : prev));
    };

    recognitionRef.current = recognition;
    isListeningRef.current = true;
    recognition.start();
    setPhase('listening');
  }, [onTranscript]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current && isListeningRef.current) {
      recognitionRef.current.stop();
      isListeningRef.current = false;
    }
  }, []);

  const handleOrbClick = () => {
    if (disabled || isSpeaking) return;
    if (phase === 'listening') {
      stopListening();
    } else if (phase === 'idle') {
      startListening();
    }
  };

  const handleClose = () => {
    recognitionRef.current?.stop();
    isListeningRef.current = false;
    if (wakeListenerRef.current) {
      wakeListenerRef.current.stop();
      wakeListenerRef.current = null;
    }
    onClose();
  };

  if (!SpeechRecognition) return null;

  const isDisabledOrBusy = disabled || isSpeaking || phase === 'processing';

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 40 }}
      className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-[rgba(6,8,16,0.97)] backdrop-blur-sm"
    >
      {/* Close */}
      <button
        onClick={handleClose}
        className="absolute top-4 right-4 p-2 rounded-lg hover:bg-secondary transition-colors"
      >
        <X className="w-5 h-5 text-muted-foreground" />
      </button>

      {/* Title */}
      <p className="font-heading text-xs tracking-widest text-primary/50 mb-10">VOICE MODE</p>

      {/* Orb */}
      <div className="relative flex items-center justify-center mb-10">
        {/* Ripple rings when listening */}
        {phase === 'listening' && [1, 2, 3].map((i) => (
          <motion.div
            key={i}
            className="absolute rounded-full border border-rose-500/30"
            initial={{ width: 100, height: 100, opacity: 0.6 }}
            animate={{ width: 100 + i * 55, height: 100 + i * 55, opacity: 0 }}
            transition={{ duration: 1.5, delay: i * 0.3, repeat: Infinity, ease: 'easeOut' }}
          />
        ))}

        {/* Ripple rings when AI speaking */}
        {isSpeaking && [1, 2, 3].map((i) => (
          <motion.div
            key={i}
            className="absolute rounded-full border border-primary/30"
            initial={{ width: 100, height: 100, opacity: 0.6 }}
            animate={{ width: 100 + i * 55, height: 100 + i * 55, opacity: 0 }}
            transition={{ duration: 1.5, delay: i * 0.3, repeat: Infinity, ease: 'easeOut' }}
          />
        ))}

        {/* Ghost logo orb button */}
        <motion.button
          onClick={handleOrbClick}
          disabled={isDisabledOrBusy}
          whileTap={{ scale: 0.93 }}
          className={`relative w-24 h-24 rounded-full flex items-center justify-center border-2 transition-all select-none overflow-hidden ${
            phase === 'listening'
              ? 'border-rose-500/70 shadow-[0_0_20px_rgba(244,63,94,0.3)]'
              : isSpeaking
              ? 'border-primary/60 shadow-[0_0_20px_rgba(100,200,255,0.3)]'
              : isDisabledOrBusy
              ? 'border-primary/20 opacity-50 cursor-not-allowed'
              : 'border-primary/40 hover:border-primary/70 hover:shadow-[0_0_16px_rgba(100,200,255,0.2)]'
          }`}
          style={{
            userSelect: 'none',
            WebkitTapHighlightColor: 'transparent',
            animation: phase === 'idle' && !isSpeaking ? 'orb-pulse 3s ease-in-out infinite' : undefined,
          }}
        >
          <img src={NEW_LOGO} alt="PhantomAI" className="w-full h-full object-cover rounded-full" />
          {/* Icon overlay */}
          <div className="absolute inset-0 flex items-center justify-center rounded-full">
            {phase === 'listening' && (
              <div className="bg-rose-500/40 rounded-full p-1.5">
                <MicOff className="w-5 h-5 text-rose-300" />
              </div>
            )}
            {isSpeaking && (
              <div className="bg-primary/30 rounded-full p-1.5">
                <Volume2 className="w-5 h-5 text-primary" />
              </div>
            )}
          </div>
        </motion.button>
      </div>

      {/* Status label */}
      <p className="text-sm text-muted-foreground font-body tracking-wide text-center">
        {phase === 'listening' && <span className="text-rose-400">Listening... tap to stop</span>}
        {phase === 'processing' && <span className="text-primary/60">Processing...</span>}
        {isSpeaking && <span className="text-primary">PhantomAI is speaking...</span>}
        {phase === 'idle' && !isSpeaking && !disabled && (
          <span>Tap to speak · or say <span className="text-primary">"Hey Phantom"</span></span>
        )}
        {phase === 'idle' && !isSpeaking && disabled && <span className="text-primary/40">Waiting for response...</span>}
      </p>
    </motion.div>
  );
}