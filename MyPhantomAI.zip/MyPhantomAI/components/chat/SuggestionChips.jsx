import React from 'react';
import { motion } from 'framer-motion';
import { Newspaper, TrendingUp, Brain, Cloud, Target, BookOpen } from 'lucide-react';

const suggestions = [
  { text: "What's happening in the world today?", label: "Today's news", icon: Newspaper },
  { text: "What are the latest AI developments?", label: "Latest in AI", icon: Brain },
  { text: "Help me plan my day effectively", label: "Plan my day", icon: Target },
  { text: "Teach me something interesting I don't know", label: "Surprise me", icon: BookOpen },
];

export default function SuggestionChips({ onSelect }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="flex flex-wrap gap-2 px-4 pb-3"
    >
      {suggestions.map((s, i) => {
        const Icon = s.icon;
        return (
          <motion.button
            key={i}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => onSelect(s.text)}
            className="flex items-center gap-2 text-[11px] font-body px-3 py-2 rounded-full bg-[rgba(13,26,46,0.8)] border border-[rgba(100,200,255,0.2)] text-primary/70 hover:bg-[rgba(100,200,255,0.1)] hover:border-primary/50 hover:text-[#c8e6ff] transition-all tracking-wide"
          >
            <Icon className="w-3 h-3" />
            {s.label}
          </motion.button>
        );
      })}
    </motion.div>
  );
}