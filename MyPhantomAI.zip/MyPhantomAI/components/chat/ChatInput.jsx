import React, { useRef, useEffect, useState } from 'react';
import { Send, Mic, MicOff, Paperclip, X, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function ChatInput({ onSend, disabled, voiceMode, onToggleVoice }) {
  const textareaRef = useRef(null);
  const fileInputRef = useRef(null);
  const [attachedFiles, setAttachedFiles] = useState([]);

  const handleSubmit = () => {
    const text = textareaRef.current?.value.trim();
    if ((!text && attachedFiles.length === 0) || disabled) return;
    onSend(text || '', attachedFiles);
    textareaRef.current.value = '';
    textareaRef.current.style.height = 'auto';
    setAttachedFiles([]);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleInput = () => {
    const el = textareaRef.current;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 120) + 'px';
  };

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files || []);
    const valid = files.filter((f) =>
      f.type.startsWith('text/') ||
      f.type === 'application/pdf' ||
      f.name.endsWith('.md') ||
      f.name.endsWith('.txt') ||
      f.name.endsWith('.csv') ||
      f.name.endsWith('.json') ||
      f.name.endsWith('.docx')
    );
    setAttachedFiles((prev) => [...prev, ...valid].slice(0, 3));
    e.target.value = '';
  };

  const removeFile = (idx) => setAttachedFiles((prev) => prev.filter((_, i) => i !== idx));

  useEffect(() => {
    if (!disabled && !voiceMode) textareaRef.current?.focus();
  }, [disabled, voiceMode]);

  const SpeechSupported = !!(window.SpeechRecognition || window.webkitSpeechRecognition);

  return (
    <div className="relative z-10 border-t border-[rgba(100,200,255,0.08)] bg-[rgba(6,8,16,0.85)]" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
      {/* Attached files preview */}
      <AnimatePresence>
        {attachedFiles.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="flex flex-wrap gap-2 px-4 pt-2"
          >
            {attachedFiles.map((file, idx) => (
              <div key={idx} className="flex items-center gap-1.5 bg-primary/10 border border-primary/25 rounded-lg px-2.5 py-1.5 text-[11px] text-primary max-w-[180px]">
                <FileText className="w-3 h-3 flex-shrink-0" />
                <span className="truncate">{file.name}</span>
                <button onClick={() => removeFile(idx)} className="flex-shrink-0 ml-1 hover:text-rose-400 transition-colors">
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex gap-3 px-4 pt-3 pb-3 items-end">
        <textarea
          ref={textareaRef}
          rows={1}
          disabled={disabled || voiceMode}
          placeholder={voiceMode ? 'Voice mode active...' : 'Query the phantom...'}
          onKeyDown={handleKeyDown}
          onInput={handleInput}
          className="flex-1 bg-[rgba(13,26,46,0.8)] border border-[rgba(100,200,255,0.2)] rounded-lg px-4 py-3 text-[#c8d8f0] font-body text-[13px] outline-none placeholder:text-primary/20 focus:border-primary/50 transition-colors resize-none leading-relaxed disabled:opacity-50"
        />

        {/* File attach */}
        <input ref={fileInputRef} type="file" multiple className="hidden" onChange={handleFileChange} accept=".txt,.md,.csv,.json,.pdf,.docx,text/*" />
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => fileInputRef.current?.click()}
          disabled={disabled || voiceMode}
          className={`w-10 h-10 rounded-lg border flex items-center justify-center flex-shrink-0 transition-all select-none disabled:opacity-40 ${
            attachedFiles.length > 0
              ? 'bg-primary/20 border-primary/60 text-primary'
              : 'bg-primary/10 border-primary/30 text-primary/80 hover:bg-primary/20 hover:border-primary/60'
          }`}
          title="Attach file for context"
        >
          <Paperclip className="w-4 h-4" />
        </motion.button>

        {/* Voice mode toggle */}
        {SpeechSupported && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onToggleVoice}
            className={`w-10 h-10 rounded-lg border flex items-center justify-center flex-shrink-0 transition-all select-none ${
              voiceMode
                ? 'bg-rose-500/20 border-rose-500/50 text-rose-400'
                : 'bg-primary/10 border-primary/30 text-primary/80 hover:bg-primary/20 hover:border-primary/60'
            }`}
            style={{ userSelect: 'none', WebkitTapHighlightColor: 'transparent' }}
            title={voiceMode ? 'Exit voice mode' : 'Enter voice mode'}
          >
            {voiceMode ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </motion.button>
        )}

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleSubmit}
          disabled={disabled || voiceMode}
          className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/30 text-primary/80 flex items-center justify-center hover:bg-primary/20 hover:border-primary/60 transition-all flex-shrink-0 disabled:opacity-50"
        >
          <Send className="w-4 h-4" />
        </motion.button>
      </div>
    </div>
  );
}