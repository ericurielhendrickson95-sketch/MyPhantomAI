import React from 'react';
import { Lock, Menu, Brain, ChevronLeft } from 'lucide-react';

export default function ChatHeader({ onToggleSidebar, memoryCount, hasActiveConversation, onBack }) {
  return (
    <div className="relative z-10 flex items-center gap-3 px-4 py-3 border-b border-[rgba(100,200,255,0.12)] bg-[rgba(6,8,16,0.85)]">
      {hasActiveConversation ?
      <button
        onClick={onBack}
        className="md:hidden p-2 rounded-lg hover:bg-secondary transition-colors">
        
          <ChevronLeft className="w-4 h-4 text-primary" />
        </button> :

      <button
        onClick={onToggleSidebar}
        className="md:hidden p-2 rounded-lg hover:bg-secondary transition-colors">
        
          <Menu className="w-4 h-4 text-primary" />
        </button>
      }

      {/* Orb */}
      <img
        src="https://media..com/images/public/69fa9e4b7a5f8d62d51732e5/3a0e11972_NewProject.png"
        alt="PhantomAI"
        className="w-9 h-9 rounded-full flex-shrink-0"
        style={{ animation: 'orb-pulse 3s ease-in-out infinite' }}
      />

      <div className="font-heading text-base font-bold tracking-[0.12em] text-[#c8e6ff]">
        PHANTOM<span className="text-primary/45 font-normal">AI</span>
      </div>

      {/* Memory indicator */}
      {memoryCount > 0 &&
      <div className="hidden sm:flex items-center gap-1.5 ml-2 bg-accent/10 border border-accent/25 rounded-full px-2.5 py-1 text-[10px] text-accent tracking-wide">
          <Brain className="w-3 h-3" />
          {memoryCount} memories
        </div>
      }

      {/* Secure badge */}
      <div className="flex items-center gap-1.5 ml-auto bg-emerald-500/10 border border-emerald-500/25 rounded-full px-2.5 py-1 text-[10px] text-emerald-400 tracking-wide">
        <Lock className="w-2.5 h-2.5" />
        <span className="hidden sm:inline">ENCRYPTED</span>
        <div
          className="w-1.5 h-1.5 rounded-full bg-emerald-500 ml-1"
          style={{ animation: 'status-blink 2s steps(1) infinite' }} />
        
      </div>
    </div>);

}