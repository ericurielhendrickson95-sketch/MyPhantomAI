import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Globe, Copy, Check, FileText } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import FileDownloadBubble from './FileDownloadBubble';

export default function MessageBubble({ message }) {
  const [copied, setCopied] = React.useState(false);
  const isUser = message.role === 'user';

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    toast.success('Copied to clipboard');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`flex gap-3 items-start ${isUser ? 'flex-row-reverse' : ''}`}
    >
      {/* Avatar */}
      {isUser ? (
        <div className="w-7 h-7 rounded-full flex items-center justify-center text-[8px] font-bold tracking-wide flex-shrink-0 border bg-[#1a0d2e] border-[rgba(180,100,255,0.4)] text-[rgba(180,100,255,0.9)]">
          YOU
        </div>
      ) : (
        <img
          src="https://media.base44.com/images/public/69fa9e4b7a5f8d62d51732e5/3a0e11972_NewProject.png"
          alt="PhantomAI"
          className="w-7 h-7 rounded-full flex-shrink-0"
        />
      )}

      {/* Bubble */}
      <div className="group max-w-[82%] relative">
        {/* Attached files (user messages) */}
        {isUser && message.attached_files?.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mb-1.5 justify-end">
            {message.attached_files.map((name, i) => (
              <div key={i} className="flex items-center gap-1 bg-[rgba(100,200,255,0.08)] border border-primary/20 rounded-full px-2 py-0.5 text-[10px] text-primary/70">
                <FileText className="w-2.5 h-2.5" />
                {name}
              </div>
            ))}
          </div>
        )}
        <div
          className={`px-4 py-3 text-[13px] leading-relaxed ${
            isUser
              ? 'bg-[rgba(26,13,46,0.92)] border border-[rgba(180,100,255,0.15)] text-[#d8c8f0] rounded-xl rounded-tr-sm'
              : 'bg-[rgba(13,26,46,0.92)] border border-[rgba(100,200,255,0.15)] text-[#c8d8f0] rounded-xl rounded-tl-sm'
          }`}
        >
          {isUser ? (
            <p className="whitespace-pre-wrap">{message.content}</p>
          ) : (
            <ReactMarkdown
              className="prose prose-sm prose-invert max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0"
              components={{
                strong: ({ children }) => (
                  <strong className="text-[#c8e6ff] font-bold">{children}</strong>
                ),
                p: ({ children }) => <p className="my-1.5 leading-relaxed">{children}</p>,
                ul: ({ children }) => <ul className="my-1.5 ml-4 list-disc">{children}</ul>,
                ol: ({ children }) => <ol className="my-1.5 ml-4 list-decimal">{children}</ol>,
                li: ({ children }) => <li className="my-0.5">{children}</li>,
                code: ({ inline, children }) =>
                  inline ? (
                    <code className="px-1 py-0.5 rounded bg-[rgba(100,200,255,0.1)] text-primary text-xs font-body">
                      {children}
                    </code>
                  ) : (
                    <pre className="bg-[rgba(0,0,0,0.4)] rounded-lg p-3 overflow-x-auto my-2 text-xs">
                      <code className="text-primary font-body">{children}</code>
                    </pre>
                  ),
                a: ({ children, href }) => (
                  <a href={href} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                    {children}
                  </a>
                ),
              }}
            >
              {message.content}
            </ReactMarkdown>
          )}

          {message.generated_file && !isUser && (
            <FileDownloadBubble
              filename={message.generated_file.filename}
              content={message.generated_file.content}
            />
          )}

          {message.used_web && !isUser && (
            <div className="mt-2 inline-flex items-center gap-1.5 bg-[rgba(34,197,94,0.1)] border border-[rgba(34,197,94,0.2)] rounded-full px-2 py-0.5 text-[10px] text-emerald-400">
              <Globe className="w-3 h-3" />
              web search used
            </div>
          )}
        </div>

        {/* Copy button for AI messages */}
        {!isUser && (
          <button
            onClick={handleCopy}
            className="absolute -bottom-1 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-secondary rounded-full p-1.5 border border-border"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-muted-foreground" />}
          </button>
        )}
      </div>
    </motion.div>
  );
}