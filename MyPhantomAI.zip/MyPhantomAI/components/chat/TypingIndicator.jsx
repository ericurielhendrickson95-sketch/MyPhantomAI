import React from 'react';
import { motion } from 'framer-motion';

export default function TypingIndicator({ status }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="flex items-center gap-3"
    >
      <div className="w-7 h-7 rounded-full flex items-center justify-center text-[8px] font-bold tracking-wide flex-shrink-0 bg-[#0d1a2e] border border-[rgba(100,200,255,0.4)] text-[rgba(100,200,255,0.9)] font-heading">
        PH
      </div>
      <div className="flex items-center gap-3">
        <div className="flex gap-1 px-4 py-3 bg-[rgba(13,26,46,0.92)] border border-[rgba(100,200,255,0.15)] rounded-xl rounded-tl-sm">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="w-[5px] h-[5px] rounded-full bg-primary/60"
              style={{
                animation: 'bounce-dot 1.2s ease infinite',
                animationDelay: `${i * 0.2}s`,
              }}
            />
          ))}
        </div>
        {status && (
          <span className="text-[10px] text-primary/40 tracking-wide">{status}</span>
        )}
      </div>
    </motion.div>
  );
}