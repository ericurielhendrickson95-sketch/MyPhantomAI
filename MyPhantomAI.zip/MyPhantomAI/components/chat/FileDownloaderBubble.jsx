import React from 'react';
import { FileText, Download } from 'lucide-react';
import { motion } from 'framer-motion';

export default function FileDownloadBubble({ filename, content }) {
  const handleDownload = () => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const lines = content.split('\n').length;
  const words = content.split(/\s+/).filter(Boolean).length;

  return (
    <motion.button
      onClick={handleDownload}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className="mt-3 flex items-center gap-3 w-full max-w-xs px-4 py-3 rounded-xl bg-[rgba(100,200,255,0.06)] border border-primary/25 hover:border-primary/50 hover:bg-primary/10 transition-all text-left group"
    >
      <div className="w-9 h-9 rounded-lg bg-primary/15 border border-primary/25 flex items-center justify-center flex-shrink-0">
        <FileText className="w-4 h-4 text-primary" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-bold text-primary truncate">{filename}</p>
        <p className="text-[10px] text-muted-foreground">{words} words · {lines} lines</p>
      </div>
      <Download className="w-4 h-4 text-primary/50 group-hover:text-primary transition-colors flex-shrink-0" />
    </motion.button>
  );
}