import React, { useState, useEffect } from 'react';
import {  } from '@/api/Client';
import { Volume2, Loader2, Check } from 'lucide-react';
import { motion } from 'framer-motion';

const STYLES = [
  { id: 'calm',       label: 'Calm',       desc: 'Slow, soothing' },
  { id: 'default',    label: 'Default',    desc: 'Balanced, natural' },
  { id: 'energetic',  label: 'Energetic',  desc: 'Fast, upbeat' },
  { id: 'mysterious', label: 'Mysterious', desc: 'Deep, deliberate' },
  { id: 'formal',     label: 'Formal',     desc: 'Clear, composed' },
];

export default function VoiceToneSettings() {
  const [style, setStyle] = useState('default');
  const [speed, setSpeed] = useState(1.0);
  const [pitch, setPitch] = useState(0.9);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    .auth.me().then((u) => {
      if (u?.voice_style) setStyle(u.voice_style);
      if (u?.voice_speed != null) setSpeed(u.voice_speed);
      if (u?.voice_pitch != null) setPitch(u.voice_pitch);
    }).catch(() => {});
  }, []);

  const handleSave = async () => {
    setSaving(true);
    await .auth.updateMe({ voice_style: style, voice_speed: speed, voice_pitch: pitch });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-xl bg-[rgba(13,26,46,0.7)] border border-[rgba(100,200,255,0.12)] overflow-hidden"
    >
      <div className="px-4 py-3 border-b border-[rgba(100,200,255,0.08)]">
        <div className="flex items-center gap-2">
          <Volume2 className="w-3.5 h-3.5 text-primary/70" />
          <span className="text-[11px] font-heading tracking-widest text-primary/70">VOICE TONE</span>
        </div>
      </div>

      <div className="px-4 py-4 space-y-5">
        {/* Style selector */}
        <div>
          <p className="text-[11px] text-muted-foreground mb-2 tracking-wide">Speaking Style</p>
          <div className="grid grid-cols-2 gap-2">
            {STYLES.map((s) => (
              <button
                key={s.id}
                onClick={() => setStyle(s.id)}
                className={`text-left px-3 py-2.5 rounded-lg border transition-all select-none ${
                  style === s.id
                    ? 'border-primary/50 bg-primary/10 text-primary'
                    : 'border-border bg-secondary/20 text-muted-foreground hover:border-primary/25 hover:text-foreground'
                }`}
              >
                <p className="text-xs font-bold">{s.label}</p>
                <p className="text-[10px] opacity-70">{s.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Speed slider */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <p className="text-[11px] text-muted-foreground tracking-wide">Speed</p>
            <span className="text-[10px] text-primary font-body">{speed.toFixed(1)}x</span>
          </div>
          <input
            type="range"
            min={0.5}
            max={2.0}
            step={0.1}
            value={speed}
            onChange={(e) => setSpeed(parseFloat(e.target.value))}
            className="w-full accent-primary h-1 rounded-full bg-secondary cursor-pointer"
          />
          <div className="flex justify-between text-[9px] text-muted-foreground/50 mt-1">
            <span>Slow</span><span>Fast</span>
          </div>
        </div>

        {/* Pitch slider */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <p className="text-[11px] text-muted-foreground tracking-wide">Pitch</p>
            <span className="text-[10px] text-primary font-body">{pitch.toFixed(1)}</span>
          </div>
          <input
            type="range"
            min={0.5}
            max={1.5}
            step={0.1}
            value={pitch}
            onChange={(e) => setPitch(parseFloat(e.target.value))}
            className="w-full accent-primary h-1 rounded-full bg-secondary cursor-pointer"
          />
          <div className="flex justify-between text-[9px] text-muted-foreground/50 mt-1">
            <span>Low</span><span>High</span>
          </div>
        </div>

        {/* Save button */}
        <button
          onClick={handleSave}
          disabled={saving}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-primary/10 border border-primary/30 text-primary text-xs hover:bg-primary/20 transition-all disabled:opacity-50 select-none font-body"
        >
          {saving ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
          ) : saved ? (
            <><Check className="w-3.5 h-3.5" /> Saved</>
          ) : (
            'Save Voice Settings'
          )}
        </button>
      </div>
    </motion.div>
  );
}