import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import Landing from '../pages/Landing';

export default function PaywallGate({ children }) {
  const [status, setStatus] = useState('loading'); // 'loading' | 'unauthenticated' | 'unsubscribed' | 'granted'

  useEffect(() => {
    const check = async () => {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        setStatus('unauthenticated');
        return;
      }
      const user = await base44.auth.me();
      if (user?.role === 'admin' || user?.is_subscribed) {
        setStatus('granted');
      } else {
        setStatus('unsubscribed');
      }
    };
    check();
  }, []);

  if (status === 'loading') {
    return (
      <div className="fixed inset-0 bg-background grid-bg flex items-center justify-center" style={{ height: '100dvh' }}>
        <div className="scanline-overlay" />
        <div className="flex flex-col items-center gap-3">
          <div
            className="w-12 h-12 rounded-full bg-[#0d1a2e] border-2 border-primary/50 flex items-center justify-center"
            style={{ animation: 'orb-pulse 1.5s ease-in-out infinite' }}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="rgba(100,200,255,0.9)" strokeWidth="1.5" className="w-6 h-6">
              <path d="M12 2C7 2 3 6 3 11c0 3.5 2 6.5 5 8l-1 3h10l-1-3c3-1.5 5-4.5 5-8 0-5-4-9-9-9z" />
              <circle cx="9" cy="10" r="1.5" fill="rgba(100,200,255,0.9)" stroke="none" />
              <circle cx="15" cy="10" r="1.5" fill="rgba(100,200,255,0.9)" stroke="none" />
            </svg>
          </div>
          <p className="font-heading text-xs tracking-widest text-primary/50">INITIALIZING...</p>
        </div>
      </div>
    );
  }

  if (status === 'unauthenticated') {
    return <Landing />;
  }

  // unsubscribed users get in — Chat will show the paywall modal after free limit
  return children;
}