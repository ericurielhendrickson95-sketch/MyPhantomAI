import React from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageSquare, Brain, Settings, CalendarClock } from 'lucide-react';

const tabs = [
  { id: 'chat', label: 'Threads', icon: MessageSquare, path: '/' },
  { id: 'memories', label: 'Memories', icon: Brain, path: '/memories' },
  { id: 'tasks', label: 'Tasks', icon: CalendarClock, path: '/tasks' },
  { id: 'settings', label: 'Settings', icon: Settings, path: '/settings' },
];

export default function BottomNav({ activeTab, onMemoriesTab }) {
  const navigate = useNavigate();

  const handleTab = (tab) => {
    if (tab.id === 'memories' && onMemoriesTab) {
      onMemoriesTab();
    } else {
      navigate(tab.path);
    }
  };

  return (
    <div
      className="relative z-20 flex items-center border-t border-[rgba(100,200,255,0.1)] bg-[rgba(6,8,16,0.95)]"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => handleTab(tab)}
            className={`relative flex-1 flex flex-col items-center gap-1 py-3 transition-all select-none ${
              isActive
                ? 'text-primary'
                : 'text-muted-foreground hover:text-foreground'
            }`}
            style={{ userSelect: 'none', WebkitTapHighlightColor: 'transparent' }}
          >
            <Icon className={`w-5 h-5 transition-all ${isActive ? 'drop-shadow-[0_0_6px_rgba(100,200,255,0.6)]' : ''}`} />
            <span className={`text-[10px] tracking-wide font-heading ${isActive ? 'text-primary' : 'text-muted-foreground'}`}>
              {tab.label}
            </span>
            {isActive && (
              <div className="absolute bottom-0 w-6 h-[2px] rounded-full bg-primary" style={{ boxShadow: '0 0 6px rgba(100,200,255,0.7)' }} />
            )}
          </button>
        );
      })}
    </div>
  );
}