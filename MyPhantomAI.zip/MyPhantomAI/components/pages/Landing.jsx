import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Lock, Zap, Brain, Globe, Shield, ChevronRight, Loader2 } from 'lucide-react';

const STRIPE_LINK = 'https://buy.stripe.com/8x214n4SY9SggpsdOfabK03';

const features = [
  { icon: Brain, label: 'Self-Learning Memory', desc: 'Remembers everything you share across sessions' },
  { icon: Globe, label: 'Live Web Access', desc: 'Real-time internet search for up-to-date answers' },
  { icon: Zap, label: 'Adaptive Intelligence', desc: 'Gets smarter and more personal the more you use it' },
  { icon: Shield, label: 'End-to-End Encrypted', desc: 'Your conversations are fully private and secure' },
];

export default function Landing() {
  const [verifying, setVerifying] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = () => {
    base44.auth.redirectToLogin('/');
  };

  const handleSubscribeVerify = async () => {
    setVerifying(true);
    setError('');
    try {
      await base44.auth.updateMe({ is_subscribed: true, subscribed_at: new Date().toISOString() });
      window.location.reload();
    } catch (e) {
      setError('Could not verify subscription. Please make sure you are logged in first.');
    } finally {
      setVerifying(false);
    }
  };

  return (
    <div className="bg-background grid-bg flex flex-col items-center justify-center p-4 relative overflow-auto" style={{ minHeight: '100dvh', position: 'relative', zIndex: 0 }}>
      <div className="scanline-overlay" />

      {/* Corner decorations */}
      <div className="absolute top-4 left-4 w-8 h-8 border-t-2 border-l-2 border-primary/30" />
      <div className="absolute bottom-4 right-4 w-8 h-8 border-b-2 border-r-2 border-primary/30" />
      <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-primary/30" />
      <div className="absolute bottom-4 left-4 w-8 h-8 border-b-2 border-l-2 border-primary/30" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-2xl"
      >
        {/* Header */}
        <div className="text-center mb-10">
          {/* Orb */}
          <div className="flex justify-center mb-5">
            <img
              src="https://media.base44.com/images/public/69fa9e4b7a5f8d62d51732e5/3a0e11972_NewProject.png"
              alt="PhantomAI"
              className="w-16 h-16 rounded-full"
              style={{ animation: 'orb-pulse 3s ease-in-out infinite' }}
            />
          </div>

          <h1 className="font-heading text-4xl font-bold tracking-[0.15em] text-[#c8e6ff] mb-2">
            PHANTOM<span className="text-primary/40 font-normal">AI</span>
          </h1>
          <p className="text-muted-foreground text-sm tracking-wider font-body">
            YOUR SELF-LEARNING AI COMPANION
          </p>

          <div className="flex items-center justify-center gap-2 mt-3">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" style={{ animation: 'status-blink 2s steps(1) infinite' }} />
            <span className="text-[11px] text-emerald-400 tracking-widest">SIGNAL ONLINE</span>
          </div>
        </div>

        {/* Features grid */}
        <div className="grid grid-cols-2 gap-3 mb-8">
          {features.map((f, i) => {
            const Icon = f.icon;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * i + 0.3 }}
                className="p-4 rounded-xl bg-[rgba(13,26,46,0.6)] border border-[rgba(100,200,255,0.1)] hover:border-primary/25 transition-colors"
              >
                <Icon className="w-5 h-5 text-primary mb-2" />
                <p className="text-xs font-bold text-[#c8e6ff] tracking-wide mb-1">{f.label}</p>
                <p className="text-[11px] text-muted-foreground leading-relaxed">{f.desc}</p>
              </motion.div>
            );
          })}
        </div>

        {/* CTA Card */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="rounded-2xl bg-[rgba(13,26,46,0.8)] border border-[rgba(100,200,255,0.15)] p-6 text-center"
          style={{ animation: 'glow-border 4s ease infinite' }}
        >
          <Lock className="w-6 h-6 text-primary/50 mx-auto mb-3" />
          <h2 className="font-heading text-lg font-bold tracking-[0.1em] text-[#c8e6ff] mb-1">FULL ACCESS</h2>
          <div className="flex items-baseline justify-center gap-1 mb-2">
            <span className="text-3xl font-bold text-primary font-heading">$35</span>
            <span className="text-muted-foreground text-sm">/month</span>
          </div>
          <p className="text-muted-foreground text-xs mb-5 leading-relaxed">
            Unlock unlimited conversations, persistent memory, and live web intelligence.
          </p>

          {/* Steps */}
          <div className="flex flex-col sm:flex-row gap-3 justify-center mb-5">
            {/* Step 1 - Sign in */}
            <button
              onClick={handleLogin}
              className="flex-1 flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-secondary border border-border text-sm text-foreground hover:bg-secondary/80 transition-all font-body"
            >
              <span className="w-5 h-5 rounded-full bg-primary/20 border border-primary/30 text-[10px] font-bold text-primary flex items-center justify-center flex-shrink-0">1</span>
              Create Account / Sign In
              <ChevronRight className="w-4 h-4 text-muted-foreground ml-auto" />
            </button>

            {/* Step 2 - Subscribe */}
            <a
              href={STRIPE_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-primary/10 border border-primary/30 text-sm text-primary hover:bg-primary/20 transition-all font-body"
            >
              <span className="w-5 h-5 rounded-full bg-primary/20 border border-primary/30 text-[10px] font-bold text-primary flex items-center justify-center flex-shrink-0">2</span>
              Subscribe — $35/month
              <ChevronRight className="w-4 h-4 text-primary/50 ml-auto" />
            </a>
          </div>

          {/* Verify button */}
          <button
            onClick={handleSubscribeVerify}
            disabled={verifying}
            className="w-full flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 text-sm hover:bg-emerald-500/20 transition-all font-body disabled:opacity-50"
          >
            {verifying ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Zap className="w-4 h-4" />
            )}
            I've subscribed — Activate Access
          </button>

          {error && (
            <p className="text-xs text-destructive mt-3">{error}</p>
          )}

          <p className="text-[10px] text-muted-foreground mt-4">
            Complete steps 1 & 2, then click "Activate Access" to unlock PhantomAI.
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
}