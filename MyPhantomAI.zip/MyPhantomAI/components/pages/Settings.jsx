import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { LogOut, Trash2, User, Shield, AlertTriangle, Loader2, ChevronRight, FileText } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import BottomNav from '../components/BottomNav';
import VoiceToneSettings from '../components/settings/VoiceToneSettings';
import ThemeCustomization from '../components/settings/ThemeCustomization';

export default function Settings() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteInput, setDeleteInput] = useState('');
  const [deleting, setDeleting] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const handleLogout = async () => {
    setLoggingOut(true);
    base44.auth.logout('/');
  };

  const handleDeleteAccount = async () => {
    if (deleteInput !== 'DELETE') return;
    setDeleting(true);
    try {
      await base44.auth.updateMe({ is_subscribed: false, account_deleted: true });
      base44.auth.logout('/');
    } catch (e) {
      setDeleting(false);
    }
  };

  return (
    <div className="flex flex-col bg-background grid-bg" style={{ height: '100%' }}>
      <div className="scanline-overlay" />

      {/* Header */}
      <div className="relative z-10 flex items-center gap-3 px-4 py-4 border-b border-[rgba(100,200,255,0.12)] bg-[rgba(6,8,16,0.85)]">
        <div
          className="w-8 h-8 rounded-full bg-[#0d1a2e] border border-primary/40 flex items-center justify-center flex-shrink-0"
          style={{ animation: 'orb-pulse 3s ease-in-out infinite' }}
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="rgba(100,200,255,0.9)" strokeWidth="1.5" className="w-4 h-4">
            <path d="M12 2C7 2 3 6 3 11c0 3.5 2 6.5 5 8l-1 3h10l-1-3c3-1.5 5-4.5 5-8 0-5-4-9-9-9z" />
            <circle cx="9" cy="10" r="1.5" fill="rgba(100,200,255,0.9)" stroke="none" />
            <circle cx="15" cy="10" r="1.5" fill="rgba(100,200,255,0.9)" stroke="none" />
          </svg>
        </div>
        <h1 className="font-heading text-base font-bold tracking-[0.12em] text-[#c8e6ff]">
          SETTINGS
        </h1>
      </div>

      {/* Content */}
      <div className="relative z-10 flex-1 overflow-y-auto px-4 py-6 space-y-4 pb-24">

        {/* Account info */}
        {user && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 rounded-xl bg-[rgba(13,26,46,0.7)] border border-[rgba(100,200,255,0.12)]"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 border border-primary/25 flex items-center justify-center">
                <User className="w-5 h-5 text-primary/70" />
              </div>
              <div>
                <p className="text-sm text-foreground font-body">{user.full_name || 'User'}</p>
                <p className="text-[11px] text-muted-foreground">{user.email}</p>
              </div>
              {user.is_subscribed && (
                <div className="ml-auto flex items-center gap-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-2.5 py-1 text-[10px] text-emerald-400">
                  <Shield className="w-3 h-3" />
                  ACTIVE
                </div>
              )}
            </div>
          </motion.div>
        )}

        {/* Theme */}
        <ThemeCustomization />

        {/* Voice tone */}
        <VoiceToneSettings />

        {/* Sign out */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="rounded-xl bg-[rgba(13,26,46,0.7)] border border-[rgba(100,200,255,0.12)] overflow-hidden"
        >
          <button
            onClick={handleLogout}
            disabled={loggingOut}
            className="w-full flex items-center gap-3 px-4 py-4 hover:bg-secondary/30 transition-colors select-none"
            style={{ userSelect: 'none' }}
          >
            {loggingOut ? (
              <Loader2 className="w-4 h-4 text-muted-foreground animate-spin" />
            ) : (
              <LogOut className="w-4 h-4 text-muted-foreground" />
            )}
            <span className="text-sm text-foreground font-body">Sign Out</span>
            <ChevronRight className="w-4 h-4 text-muted-foreground ml-auto" />
          </button>
        </motion.div>

        {/* Danger zone */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="rounded-xl bg-[rgba(46,13,13,0.4)] border border-destructive/20 overflow-hidden"
        >
          <div className="px-4 py-3 border-b border-destructive/15">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-3.5 h-3.5 text-destructive/70" />
              <span className="text-[11px] font-heading tracking-widest text-destructive/70">DANGER ZONE</span>
            </div>
          </div>

          {!showDeleteConfirm ? (
            <button
              onClick={() => setShowDeleteConfirm(true)}
              className="w-full flex items-center gap-3 px-4 py-4 hover:bg-destructive/10 transition-colors select-none"
              style={{ userSelect: 'none' }}
            >
              <Trash2 className="w-4 h-4 text-destructive/70" />
              <span className="text-sm text-destructive/80 font-body">Delete Account</span>
              <ChevronRight className="w-4 h-4 text-destructive/50 ml-auto" />
            </button>
          ) : (
            <div className="px-4 py-4 space-y-3">
              <p className="text-[12px] text-muted-foreground leading-relaxed">
                This will deactivate your account and revoke access. Type <span className="text-destructive font-bold font-body">DELETE</span> to confirm.
              </p>
              <input
                type="text"
                value={deleteInput}
                onChange={(e) => setDeleteInput(e.target.value)}
                placeholder="Type DELETE to confirm"
                className="w-full bg-[rgba(0,0,0,0.3)] border border-destructive/30 rounded-lg px-3 py-2.5 text-[13px] text-foreground font-body outline-none focus:border-destructive/60 transition-colors placeholder:text-muted-foreground/40"
              />
              <div className="flex gap-2">
                <button
                  onClick={() => { setShowDeleteConfirm(false); setDeleteInput(''); }}
                  className="flex-1 py-2.5 rounded-lg bg-secondary/50 border border-border text-sm text-muted-foreground font-body select-none"
                  style={{ userSelect: 'none' }}
                >
                  Cancel
                </button>
                <button
                  onClick={handleDeleteAccount}
                  disabled={deleteInput !== 'DELETE' || deleting}
                  className="flex-1 py-2.5 rounded-lg bg-destructive/20 border border-destructive/40 text-sm text-destructive font-body disabled:opacity-40 select-none flex items-center justify-center gap-2"
                  style={{ userSelect: 'none' }}
                >
                  {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                  Delete
                </button>
              </div>
            </div>
          )}
        </motion.div>

        {/* Privacy Policy */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="rounded-xl bg-[rgba(13,26,46,0.7)] border border-[rgba(100,200,255,0.12)] overflow-hidden"
        >
          <button
            onClick={() => navigate('/privacy')}
            className="w-full flex items-center gap-3 px-4 py-4 hover:bg-secondary/30 transition-colors select-none"
            style={{ userSelect: 'none' }}
          >
            <FileText className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm text-foreground font-body">Privacy Policy</span>
            <ChevronRight className="w-4 h-4 text-muted-foreground ml-auto" />
          </button>
        </motion.div>

        {/* App info */}
        <div className="text-center pt-4">
          <p className="text-[10px] text-muted-foreground/40 tracking-widest font-heading">PHANTOMAI v1.0</p>
        </div>
      </div>

      <BottomNav activeTab="settings" />
    </div>
  );
}