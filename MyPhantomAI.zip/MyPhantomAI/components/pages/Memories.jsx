import React, { useState } from 'react';
import {  } from '@/api/Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Trash2, Tag, Search, Pencil, Check, X, BarChart2, List } from 'lucide-react';
import BottomNav from '../components/BottomNav';

const CATEGORY_META = {
  preference: { color: 'text-primary',    border: 'border-primary/20',     bg: 'bg-primary/5',     bar: 'bg-primary/60' },
  personal:   { color: 'text-accent',     border: 'border-accent/20',      bg: 'bg-accent/5',      bar: 'bg-accent/60' },
  work:       { color: 'text-emerald-400',border: 'border-emerald-400/20', bg: 'bg-emerald-400/5', bar: 'bg-emerald-400/60' },
  interest:   { color: 'text-amber-400',  border: 'border-amber-400/20',   bg: 'bg-amber-400/5',   bar: 'bg-amber-400/60' },
  habit:      { color: 'text-rose-400',   border: 'border-rose-400/20',    bg: 'bg-rose-400/5',    bar: 'bg-rose-400/60' },
  goal:       { color: 'text-cyan-400',   border: 'border-cyan-400/20',    bg: 'bg-cyan-400/5',    bar: 'bg-cyan-400/60' },
};
const CATEGORIES = Object.keys(CATEGORY_META);

function MemoryItem({ memory, onDelete, onEdit }) {
  const [editing, setEditing] = useState(false);
  const [editFact, setEditFact] = useState(memory.fact);
  const [editCategory, setEditCategory] = useState(memory.category);
  const meta = CATEGORY_META[memory.category] || CATEGORY_META.personal;

  const handleSave = () => {
    onEdit(memory.id, { fact: editFact, category: editCategory });
    setEditing(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="group p-4 rounded-xl bg-[rgba(13,26,46,0.7)] border border-[rgba(100,200,255,0.1)] hover:border-accent/25 transition-all"
    >
      {editing ? (
        <div className="space-y-2">
          <textarea
            value={editFact}
            onChange={(e) => setEditFact(e.target.value)}
            className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm text-foreground resize-none outline-none focus:border-accent/50 leading-relaxed"
            rows={3} autoFocus
          />
          <div className="flex items-center gap-2">
            <select
              value={editCategory}
              onChange={(e) => setEditCategory(e.target.value)}
              className="flex-1 bg-background border border-border rounded-md px-2 py-1.5 text-xs text-foreground outline-none focus:border-accent/50"
            >
              {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
            <button onClick={handleSave} className="p-2 rounded-lg bg-accent/20 hover:bg-accent/30 transition-colors">
              <Check className="w-4 h-4 text-accent" />
            </button>
            <button onClick={() => { setEditing(false); setEditFact(memory.fact); setEditCategory(memory.category); }} className="p-2 rounded-lg hover:bg-secondary transition-colors">
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>
        </div>
      ) : (
        <>
          <p className="text-[13px] text-foreground leading-relaxed">{memory.fact}</p>
          <div className="flex items-center justify-between mt-3">
            <span className={`inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full border ${meta.color} ${meta.border} ${meta.bg}`}>
              <Tag className="w-2.5 h-2.5" />
              {memory.category}
            </span>
            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all">
              <button onClick={() => setEditing(true)} className="p-1.5 rounded-lg hover:bg-accent/20 transition-all select-none">
                <Pencil className="w-3.5 h-3.5 text-accent/60" />
              </button>
              <button onClick={() => onDelete(memory.id)} className="p-1.5 rounded-lg hover:bg-destructive/20 transition-all select-none">
                <Trash2 className="w-3.5 h-3.5 text-destructive/50 hover:text-destructive/80" />
              </button>
            </div>
          </div>
        </>
      )}
    </motion.div>
  );
}

function MemoryDashboard({ memories }) {
  const total = memories.length;
  const byCategory = CATEGORIES.map((cat) => ({
    cat,
    count: memories.filter((m) => m.category === cat).length,
    meta: CATEGORY_META[cat],
  })).filter((c) => c.count > 0);

  const recentFact = memories[0];

  return (
    <div className="space-y-3 pb-2">
      {/* Stats row */}
      <div className="grid grid-cols-3 gap-2">
        <div className="col-span-1 p-3 rounded-xl bg-[rgba(13,26,46,0.7)] border border-[rgba(100,200,255,0.1)] text-center">
          <p className="text-2xl font-heading font-bold text-primary">{total}</p>
          <p className="text-[10px] text-muted-foreground mt-0.5">Total</p>
        </div>
        <div className="col-span-1 p-3 rounded-xl bg-[rgba(13,26,46,0.7)] border border-[rgba(100,200,255,0.1)] text-center">
          <p className="text-2xl font-heading font-bold text-accent">{byCategory.length}</p>
          <p className="text-[10px] text-muted-foreground mt-0.5">Categories</p>
        </div>
        <div className="col-span-1 p-3 rounded-xl bg-[rgba(13,26,46,0.7)] border border-[rgba(100,200,255,0.1)] text-center">
          <p className="text-2xl font-heading font-bold text-emerald-400">
            {memories.filter((m) => {
              const d = new Date(m.created_date);
              return Date.now() - d.getTime() < 7 * 24 * 60 * 60 * 1000;
            }).length}
          </p>
          <p className="text-[10px] text-muted-foreground mt-0.5">This Week</p>
        </div>
      </div>

      {/* Category breakdown */}
      {byCategory.length > 0 && (
        <div className="p-4 rounded-xl bg-[rgba(13,26,46,0.7)] border border-[rgba(100,200,255,0.1)] space-y-2">
          <p className="text-[10px] font-heading tracking-widest text-muted-foreground mb-3">BREAKDOWN</p>
          {byCategory.map(({ cat, count, meta }) => (
            <div key={cat} className="flex items-center gap-3">
              <span className={`text-[11px] w-20 capitalize ${meta.color}`}>{cat}</span>
              <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${meta.bar}`}
                  style={{ width: `${(count / total) * 100}%` }}
                />
              </div>
              <span className="text-[11px] text-muted-foreground w-4 text-right">{count}</span>
            </div>
          ))}
        </div>
      )}

      {/* Latest memory */}
      {recentFact && (
        <div className="p-3 rounded-xl bg-[rgba(100,200,255,0.04)] border border-[rgba(100,200,255,0.1)]">
          <p className="text-[10px] font-heading tracking-widest text-muted-foreground mb-1.5">LATEST SIGNAL</p>
          <p className="text-[12px] text-foreground leading-relaxed">{recentFact.fact}</p>
        </div>
      )}
    </div>
  );
}

export default function Memories() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [view, setView] = useState('list'); // 'list' | 'dashboard'
  const [categoryFilter, setCategoryFilter] = useState('all');

  const { data: memories = [] } = useQuery({
    queryKey: ['memories'],
    queryFn: () => .entities.UserMemory.list('-created_date', 100),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => .entities.UserMemory.delete(id),
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: ['memories'] });
      const previous = queryClient.getQueryData(['memories']);
      queryClient.setQueryData(['memories'], (old) => old?.filter((m) => m.id !== id) ?? []);
      return { previous };
    },
    onError: (_err, _id, ctx) => queryClient.setQueryData(['memories'], ctx.previous),
    onSettled: () => queryClient.invalidateQueries({ queryKey: ['memories'] }),
  });

  const editMutation = useMutation({
    mutationFn: ({ id, data }) => .entities.UserMemory.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['memories'] }),
  });

  const filtered = memories.filter((m) => {
    const matchSearch = m.fact.toLowerCase().includes(search.toLowerCase()) || m.category.toLowerCase().includes(search.toLowerCase());
    const matchCat = categoryFilter === 'all' || m.category === categoryFilter;
    return matchSearch && matchCat;
  });

  return (
    <div className="flex flex-col bg-background grid-bg" style={{ height: '100%' }}>
      <div className="scanline-overlay" />

      {/* Header */}
      <div className="relative z-10 flex items-center gap-3 px-4 py-4 border-b border-[rgba(100,200,255,0.12)] bg-[rgba(6,8,16,0.85)]">
        <div className="w-8 h-8 rounded-full bg-[#0d1a2e] border border-accent/40 flex items-center justify-center" style={{ animation: 'orb-pulse 3s ease-in-out infinite' }}>
          <Brain className="w-4 h-4 text-accent/80" />
        </div>
        <h1 className="font-heading text-base font-bold tracking-[0.12em] text-accent">MEMORIES</h1>
        {memories.length > 0 && <span className="text-[11px] text-muted-foreground font-body">{memories.length} stored</span>}
        {/* View toggle */}
        <div className="ml-auto flex bg-secondary/40 rounded-lg p-0.5 gap-0.5">
          <button onClick={() => setView('list')} className={`p-1.5 rounded-md transition-all select-none ${view === 'list' ? 'bg-secondary text-primary' : 'text-muted-foreground hover:text-foreground'}`}>
            <List className="w-3.5 h-3.5" />
          </button>
          <button onClick={() => setView('dashboard')} className={`p-1.5 rounded-md transition-all select-none ${view === 'dashboard' ? 'bg-secondary text-primary' : 'text-muted-foreground hover:text-foreground'}`}>
            <BarChart2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Search + filter (list view only) */}
      {view === 'list' && (
        <div className="relative z-10 px-4 py-2 border-b border-[rgba(100,200,255,0.08)] bg-[rgba(6,8,16,0.6)] space-y-2">
          <div className="flex items-center gap-2 bg-[rgba(13,26,46,0.8)] border border-[rgba(100,200,255,0.15)] rounded-lg px-3 py-2.5">
            <Search className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <input
              type="text" value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search memories..."
              className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground/40 outline-none font-body"
            />
            {search && <button onClick={() => setSearch('')}><X className="w-3.5 h-3.5 text-muted-foreground hover:text-foreground" /></button>}
          </div>
          <div className="flex gap-1 overflow-x-auto pb-0.5">
            {['all', ...CATEGORIES].map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`flex-shrink-0 px-2.5 py-1 rounded-full text-[10px] font-body capitalize border transition-all select-none ${
                  categoryFilter === cat
                    ? (cat === 'all' ? 'bg-primary/15 border-primary/30 text-primary' : `${CATEGORY_META[cat]?.bg} ${CATEGORY_META[cat]?.border} ${CATEGORY_META[cat]?.color}`)
                    : 'border-border text-muted-foreground hover:border-border/80'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Content */}
      <div className="relative z-10 flex-1 overflow-y-auto p-4 space-y-2 pb-24">
        {view === 'dashboard' ? (
          <MemoryDashboard memories={memories} />
        ) : (
          <>
            <AnimatePresence>
              {filtered.map((memory) => (
                <MemoryItem
                  key={memory.id}
                  memory={memory}
                  onDelete={(id) => deleteMutation.mutate(id)}
                  onEdit={(id, data) => editMutation.mutate({ id, data })}
                />
              ))}
            </AnimatePresence>
            {filtered.length === 0 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-20 space-y-3">
                <Brain className="w-12 h-12 mx-auto text-accent/20" />
                {search ? (
                  <p className="text-sm text-muted-foreground">No memories match "{search}"</p>
                ) : (
                  <>
                    <p className="text-sm text-muted-foreground">No memories yet.</p>
                    <p className="text-[11px] text-muted-foreground/60">PhantomAI learns about you as you chat.</p>
                  </>
                )}
              </motion.div>
            )}
          </>
        )}
      </div>

      <BottomNav activeTab="memories" />
    </div>
  );
}